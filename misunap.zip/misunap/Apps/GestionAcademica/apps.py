from django.apps import AppConfig
class GestionAcademicaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'misunap.Apps.GestionAcademica'